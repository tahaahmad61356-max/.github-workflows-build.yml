package com.example.deotakeyboard

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
        }

        val title = TextView(this).apply {
            text = "Deota Keyboard"
            textSize = 28f
            setPadding(0, 0, 0, 12)
        }
        val description = TextView(this).apply {
            text = "Enable your keyboard, then select it whenever you type. The keys use your Deota font; text sent to other apps remains ordinary text."
            textSize = 16f
            setPadding(0, 0, 0, 24)
        }
        val enable = Button(this).apply {
            text = "1. Enable Deota Keyboard"
            setOnClickListener {
                startActivity(Intent("android.settings.INPUT_METHOD_SETTINGS"))
            }
        }
        val choose = Button(this).apply {
            text = "2. Choose Deota Keyboard"
            setOnClickListener {
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }
        val help = TextView(this).apply {
            text = "\nHow to use:\n• Tap Enable and turn on Deota Keyboard.\n• Return here and tap Choose.\n• Select Deota Keyboard.\n• Open WhatsApp or another app and start typing.\n\nPrivacy: this sample keyboard has no internet permission and does not collect or send what you type."
            textSize = 15f
        }

        layout.addView(title)
        layout.addView(description)
        layout.addView(enable)
        layout.addView(choose)
        layout.addView(help)
        setContentView(layout)
    }
}
