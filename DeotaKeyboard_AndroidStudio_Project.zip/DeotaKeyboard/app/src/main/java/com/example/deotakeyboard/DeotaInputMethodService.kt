package com.example.deotakeyboard

import android.inputmethodservice.InputMethodService
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.LinearLayout
import android.widget.TextView

class DeotaInputMethodService : InputMethodService() {
    private var upperCase = true
    private var deotaTypeface: Typeface? = null

    override fun onCreate() {
        super.onCreate()
        deotaTypeface = try {
            Typeface.createFromAsset(assets, "deota.ttf")
        } catch (_: Exception) {
            Typeface.DEFAULT
        }
    }

    override fun onCreateInputView(): View {
        val keyboard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(4, 6, 4, 8)
            setBackgroundColor(0xFFE7E9EF.toInt())
        }

        addRow(keyboard, listOf("q","w","e","r","t","y","u","i","o","p"))
        addRow(keyboard, listOf("a","s","d","f","g","h","j","k","l"))
        addRow(keyboard, listOf("⇧","z","x","c","v","b","n","m","⌫"))
        addRow(keyboard, listOf("?123",",","space",".","↵"))
        return keyboard
    }

    private fun addRow(parent: LinearLayout, keys: List<String>) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        keys.forEach { key ->
            val label = when (key) {
                "space" -> "English"
                else -> if (key.length == 1 && key[0].isLetter()) {
                    if (upperCase) key.uppercase() else key
                } else key
            }
            val keyView = TextView(this).apply {
                text = label
                textSize = if (key == "space") 14f else 20f
                gravity = Gravity.CENTER
                typeface = deotaTypeface
                setTextColor(0xFF202331.toInt())
                setBackgroundColor(0xFFFFFFFF.toInt())
                elevation = 2f
                val pad = if (key == "space") 3 else 2
                setPadding(0, 11, 0, 11)
                val params = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, weightFor(key))
                params.setMargins(3, 4, 3, 4)
                layoutParams = params
                setOnClickListener { handleKey(key) }
            }
            row.addView(keyView)
        }
        parent.addView(row, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ))
    }

    private fun weightFor(key: String): Float = when (key) {
        "space" -> 4.5f
        "⇧", "⌫", "?123", "↵" -> 1.45f
        else -> 1f
    }

    private fun handleKey(key: String) {
        val connection = currentInputConnection ?: return
        when (key) {
            "⇧" -> {
                upperCase = !upperCase
                setInputView(onCreateInputView())
            }
            "⌫" -> connection.deleteSurroundingText(1, 0)
            "space" -> connection.commitText(" ", 1)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION)
                    ?: EditorInfo.IME_ACTION_NONE
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                    connection.performEditorAction(action)
                } else {
                    connection.commitText("\n", 1)
                }
            }
            "?123" -> {
                // Numeric/symbol mode placeholder; keep normal letter layout available.
                connection.commitText("", 1)
            }
            else -> {
                val value = if (upperCase) key.uppercase() else key
                connection.commitText(value, 1)
                if (upperCase) {
                    upperCase = false
                    setInputView(onCreateInputView())
                }
            }
        }
    }
}
