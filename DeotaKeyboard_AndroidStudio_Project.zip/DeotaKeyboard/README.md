# Deota Keyboard for Android

This is an Android Studio project for a basic custom keyboard (input method) that uses the supplied `deota.ttf` font to draw its key labels.

## Build and install

1. Install Android Studio on a computer.
2. Open this `DeotaKeyboard` folder in Android Studio.
3. Allow Gradle sync to finish. Android Studio may download the Android Gradle Plugin and SDK components.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location. Transfer the APK to your Android phone and install it. You may need to allow installation from that source.
6. Open **Deota Keyboard**, tap **Enable Deota Keyboard**, enable it in Android settings, return to the app, and tap **Choose Deota Keyboard**.
7. Select Deota Keyboard from the keyboard picker.

## Important limitations

- The Deota font is used to render the keyboard's key labels. The keyboard commits ordinary Unicode letters, numbers, spaces and punctuation to apps.
- Installing a font inside a keyboard does not install that font into WhatsApp, Instagram, or the Android system. Those apps will normally render the committed text using their own fonts.
- This starter project has letter keys, shift, backspace, space, and enter. The `?123` key is a placeholder, not a full symbol layout.
- It requests no internet permission and contains no analytics or text collection.

## Font file

The supplied `deota.ttf` is stored at `app/src/main/assets/deota.ttf`.
